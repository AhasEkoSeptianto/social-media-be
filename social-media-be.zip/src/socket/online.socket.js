const { getListFiendOnline } = require("../controllers/socket.controller");

const onlineUsers = new Map();

async function broadcastFriendOnline(io, userId) {
  for (const [userId, socketId] of onlineUsers) {
    const friendIds = await getListFiendOnline(userId);
    console.log(friendIds);
    const onlineFriends = [];

    for (const friendId of friendIds) {
      console.log(friendId);
      if (onlineUsers.has(friendId)) {
        onlineFriends.push(friendId);
      }
    }
    console.log(onlineFriends);
    console.log("=============================");

    io.to(socketId).emit("list_friend_online", onlineFriends);
  }
}

module.exports = (io, socket) => {
  socket.on("login", (userId) => {
    onlineUsers.set(userId, socket.id);
    broadcastFriendOnline(io, userId);
  });

  socket.on("get-friend-online", async (user_id) => {
    broadcastFriendOnline(io, user_id);
  });

  socket.on("disconnect", (reason) => {
    for (const [userId, socketId] of onlineUsers.entries()) {
      if (socketId === socket.id) {
        onlineUsers.delete(userId);
        break;
      }
    }
  });
};
