const onlineUsers = new Map();

module.exports = (io, socket) => {
  socket.on("login", (userId) => {
    console.log([...onlineUsers.keys()]);

    onlineUsers.set(userId, socket.id);
  });
  socket.on("get user active", () => {
    socket.emit("get user active", [...onlineUsers.keys()]);
  });

  socket.on("disconnect", () => {
    for (const [userId, socketId] of onlineUsers.entries()) {
      if (socketId === socket.id) {
        onlineUsers.delete(userId);
        break;
      }
    }
  });
};
